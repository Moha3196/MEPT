-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Vært: 127.0.0.1
-- Genereringstid: 29. 11 2020 kl. 21:55:22
-- Serverversion: 10.4.14-MariaDB
-- PHP-version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mept`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `testID` int(10) UNSIGNED NOT NULL,
  `questionID` int(11) NOT NULL,
  `studentID` int(6) UNSIGNED NOT NULL,
  `answerValue` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `classes`
--

CREATE TABLE `classes` (
  `id` int(2) UNSIGNED NOT NULL,
  `className` varchar(256) NOT NULL,
  `studentCount` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `belongsTo` int(10) UNSIGNED NOT NULL,
  `questionHeader` varchar(256) NOT NULL,
  `answer1` varchar(256) NOT NULL,
  `answer2` varchar(256) NOT NULL,
  `answer3` varchar(256) DEFAULT NULL,
  `answer4` varchar(256) DEFAULT NULL,
  `correctAnswer` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `tests`
--

CREATE TABLE `tests` (
  `id` int(10) UNSIGNED NOT NULL,
  `testName` varchar(256) NOT NULL,
  `status` int(3) NOT NULL COMMENT '0 = forrig, 1 = nuværende, 2 = planlagt',
  `startDate` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `endDate` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `class` varchar(255) NOT NULL COMMENT 'hvilken klasse en test er linket til (altså hvilke klasser der kan se testen)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(256) NOT NULL,
  `type` int(10) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp(),
  `inClasses` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Data dump for tabellen `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`, `last_updated`, `inClasses`) VALUES
(79, 'Elev', 'student', '32ade5e7c36fa329ea39dbc352743db40da5aa7460ec55f95b999d6371ad20170094d88d9296643f192e9d5433b8d6d817d6777632e556e96e58f741dc5b3550', 0, '2020-11-25 15:41:56', ''),
(80, 'Lærer', 'teacher', '50ecc45020be014e68d714cd076007e84a9621d9a5e589a916e45273014830b399d143a57f525554bfe9e751d97fe0fa884dbdea7b07721723b4eff39e9d28ad', 1, '2020-11-25 15:39:58', '');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `testID` (`testID`),
  ADD KEY `questionID` (`questionID`),
  ADD KEY `studentID` (`studentID`);

--
-- Indeks for tabel `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `belongsTo` (`belongsTo`);

--
-- Indeks for tabel `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- Tilføj AUTO_INCREMENT i tabel `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- Tilføj AUTO_INCREMENT i tabel `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- Tilføj AUTO_INCREMENT i tabel `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Tilføj AUTO_INCREMENT i tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_1` FOREIGN KEY (`testID`) REFERENCES `tests` (`id`),
  ADD CONSTRAINT `answers_ibfk_2` FOREIGN KEY (`questionID`) REFERENCES `questions` (`id`),
  ADD CONSTRAINT `answers_ibfk_3` FOREIGN KEY (`studentID`) REFERENCES `users` (`id`);

--
-- Begrænsninger for tabel `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`belongsTo`) REFERENCES `tests` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
